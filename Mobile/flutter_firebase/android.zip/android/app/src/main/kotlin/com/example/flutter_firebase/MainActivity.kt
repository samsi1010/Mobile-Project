package com.example.flutter_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
